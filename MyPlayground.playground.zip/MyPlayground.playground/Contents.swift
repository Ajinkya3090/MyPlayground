import UIKit

// Add data to Dictionary

var Names = ["Ajinkya" : "Kiran","Sagar" : "Akshay"]

print("Initial Data : ", Names)

Names ["Ketan"] = "Priya"
Names ["Swift"] = "Xcode"

print("Updated Data: ", Names)


//Print Data in dictionary using key

print(Names ["Ajinkya"]!)
print(Names ["Sagar"]!)


//Make a Class with list of Names

class names {
    var array = ["Om","Sai","Ram","Sham","Adi"]
}

// Print name using Object
var nms = names()
print(nms.array)


// Print name without using Object
class namess {
    var arrays = ["Om","Sai","Ram","Sham","Adi"]
}
print(namess().arrays)
